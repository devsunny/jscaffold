'use strict';
/**
 * @ngdoc function
 * @name sbAdminApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sbAdminApp
 */
angular.module('sbAdminApp', ['formly', 'formlyBootstrap', 'ui.bootstrap'])
  .controller('FormCtrl', ['$scope', 'formlyConfig', function($scope, formlyConfig) {
   

    $scope.onSubmit = onSubmit;

    $scope.model = {name: {}};

    $scope.fields = [
      {
        model: 'model.name',
        key: 'first',
        type: 'input',
        templateOptions: {
          label: 'First Name'
        }
      },
      {
        model: 'model.name',
        key: 'last',
        type: 'input',
        templateOptions: {
          label: 'Last Name'
        }
      },
      {
        key: 'age',
        type: 'input',
        templateOptions: {
          type: 'number',
          label: 'Age'
        }
      }
    ];

    function onSubmit() {
      console.log( $scope.model);
    }
  
}]);